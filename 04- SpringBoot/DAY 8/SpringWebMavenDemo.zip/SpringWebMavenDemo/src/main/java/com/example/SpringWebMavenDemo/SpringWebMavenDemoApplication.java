package com.example.SpringWebMavenDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWebMavenDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringWebMavenDemoApplication.class, args);
	}

}
