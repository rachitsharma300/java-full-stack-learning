package com.example.SpringWebMavenDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWebMavenDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
